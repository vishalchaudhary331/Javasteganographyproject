# JavaSteganographyProject
Console-based Java 8 steganography tool using LSB technique.
